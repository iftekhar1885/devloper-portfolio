const firebaseConfig = {
    apiKey: "AIzaSyAWye3bkqi1CPgEtzaduOJ-mCQeypVEgas",
    authDomain: "auth-project2021.firebaseapp.com",
    projectId: "auth-project2021",
    storageBucket: "auth-project2021.appspot.com",
    messagingSenderId: "390818165422",
    appId: "1:390818165422:web:b25832d100fbeb1895733f"
};

export default firebaseConfig;

// Auth Project2021